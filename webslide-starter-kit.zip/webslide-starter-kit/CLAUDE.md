# 강의 사이트 작업 규칙 (Claude Code용 · AGENTS.md와 같은 내용)

이 폴더는 강의 사이트 스타터 키트. 파일 4개로 구성.

| 파일 | 역할 |
|---|---|
| `index.html` | 랜딩 (강의 소개 · 일정 · 커리큘럼 · 강사 · 프롬프트 복사) |
| `slides.html` | 웹슬라이드 (16:9 무대 · 전체보기 G · PDF P · 타이머 · 복사 버튼) |
| `admin.html` | 관리자 제어판 목업 (서버 없음 · localStorage 저장) |
| `stats.php` | 심화 트랙 백엔드 뼈대 (PHP 호스팅 전용 · Vercel·GitHub Pages는 제외) |

작업 전 이 규칙을 먼저 읽고, 작업 뒤 맨 아래 **검증 체크리스트**를 전부 실행.

## 1. 문체: 순수 한국어 개조식

화면에 보이는 모든 문구(슬라이드 · 랜딩 · 관리자)에 적용.

- 제목은 명사형: `결과 활용법`, `프롬프트 비교`, `오늘의 결과물 · 나만의 강의 제안서`
- 항목은 `키워드: 짧은 설명` 또는 `A → B`
- 어미는 명사 · "~함" · "~기"로 끝맺기
- 한 항목은 한 줄 안팎. 길면 두 항목으로 쪼개기
- 숫자는 한국어 습관대로: `1편 완성`, `재참여 희망 92%`

**금지 표현 (번역투)**

| 금지 | 고친 예 |
|---|---|
| ~합니다 / ~하세요 / ~입니다 | 명사로 끝맺기 |
| 무엇을 건질 것인가 | 결과 활용법 |
| 이렇게 달라집니다 | 프롬프트 비교 |
| 1건을 완성해서 나갑니다 | 오늘의 결과물 · 강의 제안서 |
| ~를 통해 / ~에 대해 / ~하는 것이 중요 | 조사 빼고 키워드만 |

**예외**: 복사용 프롬프트("~해줘" 명령문), 인사말("수고하셨습니다"), 짧은 시스템 안내(오류·잠금 문구)

## 2. 디자인 기본값

- 폰트 하나: Pretendard Variable (제목도 같은 폰트)
- 색: 검정 `#111` · 흰색 · 회색 단계 + 강조색 머스타드 `#F6C744` 하나
- 흰 박스 + 부드러운 그림자, 테두리 없음
- 표지 · 마침 슬라이드: 머스타드 바탕 + 검정 글씨
- 휴식 슬라이드: 검정 바탕 + 큰 타이머
- 프롬프트: 검정 박스 + 오른쪽 위 흰 복사 버튼
- 색만으로 구분 금지: 아쉬운 예 = 점선 + ✕, 좋은 예 = 검정 막대 + ✓, 스위치 = ON/OFF 글자 병기
- 버튼 · 터치 영역 최소 44px, `prefers-reduced-motion` 존중

## 3. 한 화면 피팅 (슬라이드)

- 모든 크기는 무대 폭 기준 `cqi` 단위. 권장: 키커 1.6 · h1 6 · h2 3.9 · 본문 2.25 · 카드 설명 1.8 · 표 1.85 · 프롬프트 2.0
- 스크롤 없이 한 장에 전부. 넘치면 글자 축소보다 **내용 쪼개기 · 여백 줄이기** 먼저
- 표는 8행 이하, 불릿은 5개 이하 권장
- `max-width: NNch` 금지 (한 줄 문장이 두 줄로 꺾임)

**넘침 검사 스니펫** (브라우저 콘솔 · 결과가 빈 배열이어야 통과)

```js
(() => {
  const all = [...document.querySelectorAll('#stage > section.slide')];
  const cur = all.findIndex(s => s.classList.contains('active'));
  const bad = all.map((s, i) => {
    all.forEach(x => x.classList.toggle('active', x === s));  // 숨은 장은 크기가 0이라 하나씩 켜서 측정
    const c = s.querySelector('.slide-content') || s;
    return { n: i + 1, oh: c.scrollHeight - c.clientHeight, ow: c.scrollWidth - c.clientWidth };
  }).filter(r => r.oh > 4 || r.ow > 4);
  all.forEach((x, i) => x.classList.toggle('active', i === cur));
  return bad;
})();
```

## 4. 줄바꿈은 브라우저에

- 문장 중간 `<br>` 금지. 창 크기마다 엉뚱한 곳에서 끊김
- 허용: 주소·연락처처럼 원래 여러 줄인 내용뿐
- `body { word-break: keep-all; overflow-wrap: anywhere; }` 필수 (없으면 단어 중간에서 잘림)
- 제목 `text-wrap: balance`, 문단 `text-wrap: pretty`

## 5. 공개 화면은 무기명

- 후기 · 질문이 랜딩 · 슬라이드에 나갈 때 이름 없이
- 이름은 CSS로 숨기지 말고 **데이터에서 빼기** (개발자도구에 그대로 보임)
- 관리자 화면만 실명. 후기 공개는 건별 승인
- 실제 연락처 · 개인정보를 HTML · JS에 직접 넣지 않기 (정적 사이트는 누구나 소스 열람)

## 6. localStorage 접두사

- `slides.html`, `admin.html` 스크립트의 `LS = 'mykit_'` → 내 강의 고유값 (예: `ai0927_`)
- 두 파일 같은 값으로. 다른 강의와 겹치면 저장값이 섞임
- 새 저장 키도 전부 `LS + '이름'` 형태로

## 7. 슬라이드 추가 · 삭제 시 번호 동기화

슬라이드 하나를 끼우면 번호가 여러 곳에서 어긋남. 한 번에 전부 수정.

1. `slides.html` 각 `<section>`의 `aria-label="N. 제목"` 전체 재번호
2. 주석 마커 `<!-- ===== N. 제목 ===== -->` 재번호
3. `admin.html`의 `TITLES` 배열 (순서 · 제목 동일하게)
4. `admin.html`의 `BREAKS` (휴식 슬라이드 인덱스, 0부터)
5. `slides.html` 하단 `#counter` 초기값 `1 / N`
6. 랜딩에 슬라이드 장수를 적었다면 그 숫자도

## 8. 배포

- Vercel · GitHub Pages: `index.html`, `slides.html`, `admin.html`만 (정적 파일). `stats.php`는 동작 안 함
- `admin.html`은 목업 · 비밀번호 `1234`는 데모용, 보안 아님
- PHP 호스팅에서 `stats.php` 사용 시 서버 환경변수 `WEBSLIDE_KIT_ADMIN_PASSWORD` 설정 필수 (미설정이면 관리자 기능 잠김)
- 공유 미리보기: `index.html`의 `og:` 메타 4줄 + 1200x630 이미지

## 9. 검증 체크리스트 (작업 뒤 매번)

- [ ] **넘침 0건**: `slides.html`을 1280x720 창에서 열고 3번 항목 스니펫 실행 → `[]`
- [ ] **금지 문체 0건**: 아래 명령 결과가 예외(프롬프트 · 인사말 · 시스템 문구 · 이 CLAUDE.md의 금지 표 · 주석)뿐
  ```bash
  grep -nE "니다|세요|것인가|달라집|나갑|를 통해|에 대해|—" index.html slides.html admin.html
  ```
- [ ] **em dash(—) 0건**: 하이픈 `-` 사용
- [ ] **PDF 장수 = 슬라이드 수**: 크롬에서 P → 대상 "PDF로 저장" → 미리보기 페이지 수 확인 (용지 16:9 자동)
- [ ] **콘솔 오류 0건**: 세 페이지 모두 F12 → Console
- [ ] **번호 동기화**: `aria-label` 개수 = `admin.html` `TITLES.length`
- [ ] **키보드만으로 조작**: Tab으로 모든 버튼 도달, ← → 이동, G 전체보기, Esc 닫기
